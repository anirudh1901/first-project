package shoestore.saisree.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SaisreeProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SaisreeProjectApplication.class, args);
	}

}
