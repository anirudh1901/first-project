package shoestore.saisree.project.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

@Entity(name = "customer")
@Data
@Table(name = "customer")
public class Customer {

    @Id
    private String username;

    @Column
    private String password;

    @Column
    private String full_name;

    @Column
    private String contact_number;
}
