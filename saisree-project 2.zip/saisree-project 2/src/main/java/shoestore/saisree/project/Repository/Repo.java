package shoestore.saisree.project.Repository;

import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import shoestore.saisree.project.Entity.Products;

import java.util.List;
import java.util.Optional;


@Repository
public interface Repo extends JpaRepository<Products,Integer> {
    @Query(value = "SELECT * FROM product ",nativeQuery = true)
    public List<Products> findallbyuser();

    @Query(value = "SELECT * FROM product WHERE rowno =?1", nativeQuery = true)
    public Optional<Products> findById(Integer productId);



    @Transactional
    @Modifying
    @Query(value = "UPDATE product SET cart=TRUE WHERE rowno =?1",nativeQuery = true)
    public void updateValue(Integer rowno);

    @Query(value = "SELECT * FROM product WHERE cart = TRUE",nativeQuery = true)
    public List<Products> getCart();
}
