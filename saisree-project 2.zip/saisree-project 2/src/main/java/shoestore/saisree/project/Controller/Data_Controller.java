package shoestore.saisree.project.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import shoestore.saisree.project.Entity.Customer;
import shoestore.saisree.project.Entity.Products;
import shoestore.saisree.project.Service.Data_Service;

import java.util.List;
import java.util.Optional;

@RestController
@CrossOrigin
@RequestMapping("/data")
public class Data_Controller {
    @Autowired
    private Data_Service dataService;
    @GetMapping("/post")
    public List<Products> getdata(){
        return dataService.getalldata();
    }

    @GetMapping("/product/{productId}")
    public ResponseEntity<Products> getProductDetails(@PathVariable Integer productId) {
        Optional<Products> productOpt = dataService.getProductById(productId);
        if (productOpt.isPresent()) {
            return ResponseEntity.ok(productOpt.get());
        } else {
            return ResponseEntity.notFound().build();
        }
    }


    @PostMapping("/signup")
    public ResponseEntity<String> signUp(@RequestBody Customer customer) {
        return dataService.registerUser(customer);
    }

    @GetMapping("/login")
    public boolean login(@RequestBody Customer customer) {
        return dataService.validateUser(customer.getUsername(), customer.getPassword());
    }

    @PutMapping("/cart/{rowno}")
    public void cartUpdate(@PathVariable Integer rowno){
        dataService.addToCart(rowno);
    }

    @GetMapping("/cart")
    public List<Products> CartValues(){
        return dataService.getCartValues();
    }



}
