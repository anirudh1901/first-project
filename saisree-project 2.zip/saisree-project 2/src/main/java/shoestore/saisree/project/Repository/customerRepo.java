package shoestore.saisree.project.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import shoestore.saisree.project.Entity.Customer;

import java.util.Optional;

@Repository
public interface customerRepo extends JpaRepository<Customer, String> {
    Optional<Customer> findByUsername(String username);

}
