package shoestore.saisree.project.Entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;

import java.io.Serial;

@Entity(name = "product")
@Data
@Table(name = "product")
public class Products {


    @Column
    private Integer productID;
    @Column
    private String product_name;
    @Column
    private String image_link;
    @Column
    private Integer price;
    @Column
    private Integer rating;
    @Column
    private Boolean cart;
    @Id
    @Column
    private Integer rowno;


}
