package shoestore.saisree.project.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import shoestore.saisree.project.Entity.Customer;
import shoestore.saisree.project.Repository.Repo;
import shoestore.saisree.project.Entity.Products;
import shoestore.saisree.project.Repository.customerRepo;

import java.util.List;
import java.util.Optional;


@Service
public class Data_Service {
    @Autowired
    private Repo repo;

    @Autowired
    private customerRepo customerrepo;

    public List<Products> getalldata() {
        // System.out.println("Service Class");
        return repo.findallbyuser();

    }

    public Optional<Products> getProductById(Integer productId) {
        return repo.findById(productId);

    }

    public Customer saveUser(Customer customer) {
        return customerrepo.save(customer);
    }


    public ResponseEntity<String> registerUser(Customer customer) {

            if (checkUserExists(customer.getUsername())) {
                return ResponseEntity.badRequest().body("User already exists");
            }
            saveUser(customer);
            return ResponseEntity.ok("User registered successfully");
        }


    private boolean checkUserExists(String username) {
        return customerrepo.findByUsername(username).isPresent();
    }

    public boolean validateUser(String username, String password) {
        Optional<Customer> customer = customerrepo.findByUsername(username);
        if (customer.isPresent()){
            return customer.get().getPassword().equals(password);
        }
        return false;
    }

    public void addToCart(Integer rowno) {
        repo.updateValue(rowno);
        ResponseEntity.ok("Product added to Cart");
    }


    public List<Products> getCartValues() {
       return repo.getCart();
    }
}
